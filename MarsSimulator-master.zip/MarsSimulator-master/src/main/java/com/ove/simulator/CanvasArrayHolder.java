package com.ove.simulator;

public interface CanvasArrayHolder {

	HolderType  getHolderType();
	Coordinates getCoordinates();
}
