java -jar target/MarsSimulator-0.0.1-SNAPSHOT.jar sampledata.txt  
